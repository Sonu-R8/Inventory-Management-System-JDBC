import java.sql.*;
import java.util.Scanner;

public class InventorySystem {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/inventorydb"; // Replace with your DB name
        String user = "root"; // Your DB username
        String password = ""; // Your DB password

        try (Connection conn = DriverManager.getConnection(url, user, password);
                Scanner scanner = new Scanner(System.in)) {

            while (true) {
                System.out.println("\n--- Inventory Management Menu ---");
                System.out.println("1. Add Product");
                System.out.println("2. View All Products");
                System.out.println("3. Delete Product");
                System.out.println("4. Update Product");
                System.out.println("5. View Specific Product");
                System.out.println("6. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // consume newline

                if (choice == 1) {
                    System.out.print("Enter product name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter quantity: ");
                    int qty = scanner.nextInt();
                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();

                    String insertQuery = "INSERT INTO products (name, quantity, price) VALUES (?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
                        pstmt.setString(1, name);
                        pstmt.setInt(2, qty);
                        pstmt.setDouble(3, price);
                        pstmt.executeUpdate();
                        System.out.println("Product added successfully!");
                    }

                } else if (choice == 2) {
                    String selectQuery = "SELECT * FROM products";
                    try (Statement stmt = conn.createStatement();
                            ResultSet rs = stmt.executeQuery(selectQuery)) {
                        System.out.println("ID | Name | Quantity | Price");
                        while (rs.next()) {
                            System.out.printf("%d | %s | %d | %.2f\n",
                                    rs.getInt("product_id"),
                                    rs.getString("name"),
                                    rs.getInt("quantity"),
                                    rs.getDouble("price"));
                        }
                    }

                } else if (choice == 3) {
                    System.out.print("Enter Product ID to delete: ");
                    int id = scanner.nextInt();
                    String deleteQuery = "DELETE FROM products WHERE product_id = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(deleteQuery)) {
                        pstmt.setInt(1, id);
                        int result = pstmt.executeUpdate();
                        if (result > 0) {
                            System.out.println("Product deleted successfully!");
                        } else {
                            System.out.println("Product not found.");
                        }
                    }

                } else if (choice == 4) {
                    System.out.print("Enter Product ID to update: ");
                    int id = scanner.nextInt();
                    System.out.print("Enter new quantity: ");
                    int qty = scanner.nextInt();
                    System.out.print("Enter new price: ");
                    double price = scanner.nextDouble();

                    String updateQuery = "UPDATE products SET quantity = ?, price = ? WHERE product_id = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {
                        pstmt.setInt(1, qty);
                        pstmt.setDouble(2, price);
                        pstmt.setInt(3, id);
                        int result = pstmt.executeUpdate();
                        if (result > 0) {
                            System.out.println("Product updated successfully!");
                        } else {
                            System.out.println("Product not found.");
                        }
                    }

                } else if (choice == 5) {
                    System.out.print("Enter Product ID to view: ");
                    int id = scanner.nextInt();
                    String viewQuery = "SELECT * FROM products WHERE product_id = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(viewQuery)) {
                        pstmt.setInt(1, id);
                        try (ResultSet rs = pstmt.executeQuery()) {
                            if (rs.next()) {
                                System.out.printf("ID: %d | Name: %s | Quantity: %d | Price: %.2f\n",
                                        rs.getInt("product_id"),
                                        rs.getString("name"),
                                        rs.getInt("quantity"),
                                        rs.getDouble("price"));
                            } else {
                                System.out.println("Product not found.");
                            }
                        }
                    }

                } else if (choice == 6) {
                    System.out.println("Exiting...");
                    break; // Exit the loop

                } else {
                    System.out.println("Invalid choice. Please try again.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}